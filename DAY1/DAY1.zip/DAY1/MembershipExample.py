# in and not in

nums=[90.0,90,"Hello",'A']

print(90 in nums)#true
print(50 in nums)#False
print(50 not in nums)#True