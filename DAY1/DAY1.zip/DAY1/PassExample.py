for i in range(1,4):
    if(i==2):
        pass
    print(i)