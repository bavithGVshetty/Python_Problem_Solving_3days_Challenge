s1=input("Enter first String\n")
s1=input("Enter Second String\n")

print(s1+s1)