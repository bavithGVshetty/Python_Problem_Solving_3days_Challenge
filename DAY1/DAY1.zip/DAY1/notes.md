# Built in data types in python
- list()
- tuple()
- set()
- dict()
- int()
- float()
- str()
- bool()


# Input and Output

- Print(), input()

# Operators
1. Arthmatic: +,//,**
2. Assignment: =,+=,-=
3. Relational:==,>,<,>=
4. logical: or,and,not
5. Bitwise:&,|,>>,<<,~,^
6. Membership Operators: in ,not in
7. Identity :is ,is not

# Types Casting in Python
1. Implicit Type Casting
2. Explicit Type Casting

# Conditional Statements in Python
- if
- else
- elif
- if-elif
- nested if-elif-else
  
# Transfer Statements in Python
- break,continue,pass

# Iterative Statements
- While
- For

# String in Python
- Immutable
  ### Functions in String: 
    - isdigit()
    - isalpha()
    - isupper()
    - islower()
    - isalnum()
    - isspace()
    - join()
    - replace()
    - split()

