s=input("Enter a String")
result=s.replace(" ","")
print(result)
# Hello World
