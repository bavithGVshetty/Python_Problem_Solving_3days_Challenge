#is ,is not

a=[1,2,3]
b=[1,2,3]
print(a is b) #False
print(a==b)# True