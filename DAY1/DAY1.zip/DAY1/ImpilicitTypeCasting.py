a=100
b=50.5
c=a+b #int+float =float
print(type(c))

