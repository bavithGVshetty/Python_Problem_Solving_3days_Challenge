a=input("Enter the 100\n")
b=int(a)
print(type(b))

print(bool(0))# False